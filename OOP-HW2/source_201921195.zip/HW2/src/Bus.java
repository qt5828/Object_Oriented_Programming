
public class Bus extends Car 
{	
	public Bus(int n, Time in) {
		super(n,in);
	}
	public Bus()
	{
		super();
	}

}
