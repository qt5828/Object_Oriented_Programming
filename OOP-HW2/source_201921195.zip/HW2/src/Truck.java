
public class Truck extends Car 
{
	public Truck(int n, Time in) {
		super(n,in);
	}
	public Truck()
	{
		super();
	}
}
