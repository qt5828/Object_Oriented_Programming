public class Pos {
	
	public int row;
	public int col;
	public int dir; //East:1,West:2,South:3,North:4
	
	public Pos(int r, int c)
	{
		row = r;
		col = c;
		dir = 1;
	}	
	
}
